package Client;

import Common.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

/**

* UCID: nhd5
* Final clean TriviaGuessGame Client
* * Fully compatible with your final payload definitions
* * No missing methods (getQuestionText(), getAnswers(), etc.)
* * No invalid payload types (COMMAND removed)
* * Splits CHAT vs GAME EVENTS using "[CHAT]" prefix convention
    */
    public class Client {

  // ===================== Networking =====================
  private Socket socket;
  private ObjectOutputStream out;
  private ObjectInputStream in;
  private boolean connected = false;
  private long clientId = -1;

  private boolean lockedThisRound = false;
  private boolean isAway = false;
  private boolean isSpectator = false;

  // ===================== UI =====================
  private JFrame frame;

  // Connection
  private JTextField txtUser;
  private JTextField txtHost;
  private JTextField txtPort;
  private JButton btnConnect;
  private JLabel lblConnectHint;

  // Ready & Options
  private JButton btnReady;
  private JCheckBox chkAway;
  private JCheckBox chkSpectator;
  private JButton btnAddQ;

  // Categories
  private JCheckBox chkGeo;
  private JCheckBox chkSci;
  private JCheckBox chkMath;
  private JCheckBox chkHist;

  // Users
  private DefaultListModel<User> userModel;
  private JList<User> lstUsers;
  private Map<Long, User> users = new HashMap<>();

  // Chat + events
  private JTextArea txtChat;
  private JTextField txtChatInput;
  private JButton btnSendChat;
  private JTextArea txtEvents;

  // Game area
  private JLabel lblCategory;
  private JLabel lblQuestion;
  private JLabel lblTimer;
  private JButton[] answerButtons = new JButton[4];

  public static void main(String[] args) {
  SwingUtilities.invokeLater(Client::new);
  }

  public Client() {
  buildUI();
  }

  // ===========================================================
  // UI LAYOUT
  // ===========================================================
  private void buildUI() {
  frame = new JFrame("TriviaGuessGame – nhd5");
  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  frame.setSize(1150, 700);
  frame.setLocationRelativeTo(null);
  frame.setLayout(new BorderLayout());
  frame.getContentPane().setBackground(new Color(244, 240, 255));

  ```
  JPanel root = new JPanel(new BorderLayout());
  root.setBorder(new EmptyBorder(10, 10, 10, 10));
  root.setOpaque(false);

  JLabel lblTitle = new JLabel("Trivia Guess Game", SwingConstants.CENTER);
  TextFX.setTitleFont(lblTitle);
  lblTitle.setForeground(new Color(40, 40, 70));
  lblTitle.setBorder(new EmptyBorder(5, 5, 15, 5));
  root.add(lblTitle, BorderLayout.NORTH);

  JPanel center = new JPanel(new BorderLayout(10, 0));
  center.setOpaque(false);
  center.add(buildLeftColumn(), BorderLayout.WEST);
  center.add(buildGamePanel(), BorderLayout.CENTER);
  center.add(buildRightColumn(), BorderLayout.EAST);

  root.add(center, BorderLayout.CENTER);
  frame.add(root);
  frame.setVisible(true);
  ```

  }

  private JPanel buildLeftColumn() {
  JPanel col = new JPanel();
  col.setLayout(new BoxLayout(col, BoxLayout.Y_AXIS));
  col.setOpaque(false);

  ```
  col.add(buildConnectionPanel());
  col.add(Box.createVerticalStrut(8));
  col.add(buildOptionsPanel());
  col.add(Box.createVerticalStrut(8));
  col.add(buildUserPanel());

  return col;
  ```

  }

  // ===========================================================
  // CONNECTION PANEL
  // ===========================================================
  private JPanel buildConnectionPanel() {
  RoundedPanel panel = new RoundedPanel();
  panel.setLayout(new GridBagLayout());
  panel.setBorder(new TitledBorder(new LineBorder(new Color(210, 210, 230)), "Connection"));
  ((TitledBorder) panel.getBorder()).setTitleFont(TextFX.getSubtitleFont());

  ```
  GridBagConstraints c = new GridBagConstraints();
  c.insets = new Insets(2, 4, 2, 4);
  c.gridy = 0;

  // Username
  c.gridx = 0; panel.add(label("Username:"), c);
  c.gridx = 1; txtUser = new JTextField("Player", 10); panel.add(txtUser, c);

  // Host
  c.gridx = 2; panel.add(label("Host:"), c);
  c.gridx = 3; txtHost = new JTextField("localhost", 10); panel.add(txtHost, c);

  // Port
  c.gridx = 0; c.gridy = 1; panel.add(label("Port:"), c);
  c.gridx = 1; txtPort = new JTextField("3000", 6); panel.add(txtPort, c);

  // Connect button
  c.gridx = 2; c.gridwidth = 2;
  btnConnect = new JButton("Connect");
  stylePrimary(btnConnect);
  btnConnect.addActionListener(this::connectClicked);
  panel.add(btnConnect, c);

  // Hint
  c.gridx = 0; c.gridy = 2; c.gridwidth = 4;
  lblConnectHint = new JLabel("Step 1: Enter name, host, port and click Connect.");
  TextFX.setSubtitleFont(lblConnectHint);
  panel.add(lblConnectHint, c);

  return panel;
  ```

  }

  // ===========================================================
  // OPTIONS PANEL
  // ===========================================================
  private JPanel buildOptionsPanel() {
  RoundedPanel panel = new RoundedPanel();
  panel.setLayout(new BorderLayout(5, 5));
  panel.setBorder(new TitledBorder(new LineBorder(new Color(210, 210, 230)), "Ready & Options"));
  ((TitledBorder) panel.getBorder()).setTitleFont(TextFX.getSubtitleFont());

  ```
  JPanel r1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
  r1.setOpaque(false);
  btnReady = new JButton("READY");
  stylePrimary(btnReady);
  btnReady.addActionListener(e -> sendCommand("/ready"));
  r1.add(btnReady);

  JLabel hint = new JLabel("Step 2: Click READY to join next game.");
  TextFX.setSubtitleFont(hint);
  r1.add(hint);

  btnAddQ = new JButton("Add Question");
  styleSecondary(btnAddQ);
  btnAddQ.addActionListener(e -> showAddQDialog());
  r1.add(btnAddQ);

  panel.add(r1, BorderLayout.NORTH);

  JPanel r2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
  r2.setOpaque(false);

  chkAway = new JCheckBox("Away");
  chkAway.setOpaque(false);
  chkAway.addActionListener(e -> toggleAway());
  TextFX.setSubtitleFont(chkAway);

  chkSpectator = new JCheckBox("Spectator");
  chkSpectator.setOpaque(false);
  chkSpectator.addActionListener(e -> toggleSpectator());
  TextFX.setSubtitleFont(chkSpectator);

  r2.add(chkAway);
  r2.add(chkSpectator);

  panel.add(r2, BorderLayout.CENTER);

  // Categories
  RoundedPanel catPanel = new RoundedPanel();
  catPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
  catPanel.setBorder(new TitledBorder(new LineBorder(new Color(220, 215, 235)),
          "Categories (host during ready check)"));
  ((TitledBorder) catPanel.getBorder()).setTitleFont(TextFX.getSubtitleFont());

  chkGeo = makeCategory("Geography");
  chkSci = makeCategory("Science");
  chkMath = makeCategory("Math");
  chkHist = makeCategory("History");

  catPanel.add(chkGeo);
  catPanel.add(chkSci);
  catPanel.add(chkMath);
  catPanel.add(chkHist);

  panel.add(catPanel, BorderLayout.SOUTH);
  return panel;
  ```

  }

  private JCheckBox makeCategory(String text) {
  JCheckBox box = new JCheckBox(text);
  box.setOpaque(false);
  box.setSelected(true);
  TextFX.setSubtitleFont(box);
  box.addActionListener(e -> sendCategories());
  return box;
  }

  // ===========================================================
  // USER PANEL
  // ===========================================================
  private JPanel buildUserPanel() {
  RoundedPanel panel = new RoundedPanel();
  panel.setLayout(new BorderLayout());
  panel.setBorder(new TitledBorder(new LineBorder(new Color(210, 210, 230)), "Users"));
  ((TitledBorder) panel.getBorder()).setTitleFont(TextFX.getSubtitleFont());

  ```
  userModel = new DefaultListModel<>();
  lstUsers = new JList<>(userModel);
  lstUsers.setBackground(new Color(248, 246, 255));
  lstUsers.setBorder(new EmptyBorder(5, 5, 5, 5));

  lstUsers.setCellRenderer(new DefaultListCellRenderer() {
      @Override
      public Component getListCellRendererComponent(
              JList<?> list, Object value, int index,
              boolean isSelected, boolean cellHasFocus) {

          JLabel lbl = (JLabel) super.getListCellRendererComponent(
                  list, value, index, isSelected, cellHasFocus);

          if (value instanceof User u) {
              lbl.setText(u.toDisplayString());
              if (u.isAway()) lbl.setForeground(new Color(120, 120, 160));
              else if (u.isSpectator()) lbl.setForeground(new Color(70, 120, 200));
              else lbl.setForeground(new Color(40, 40, 70));
          }
          return lbl;
      }
  });

  panel.add(new JScrollPane(lstUsers), BorderLayout.CENTER);
  panel.setPreferredSize(new Dimension(290, 260));
  return panel;
  ```

  }

  // ===========================================================
  // RIGHT COLUMN (CHAT + EVENTS)
  // ===========================================================
  private JPanel buildRightColumn() {
  JPanel col = new JPanel();
  col.setLayout(new BoxLayout(col, BoxLayout.Y_AXIS));
  col.setOpaque(false);
  col.setPreferredSize(new Dimension(300, 0));

  ```
  col.add(buildChatPanel());
  col.add(Box.createVerticalStrut(8));
  col.add(buildEventsPanel());
  return col;
  ```

  }

  private JPanel buildChatPanel() {
  RoundedPanel panel = new RoundedPanel();
  panel.setLayout(new BorderLayout());
  panel.setBorder(new TitledBorder(new LineBorder(new Color(210, 210, 230)), "Chat"));
  ((TitledBorder) panel.getBorder()).setTitleFont(TextFX.getSubtitleFont());

  ```
  txtChat = new JTextArea();
  txtChat.setEditable(false);
  txtChat.setLineWrap(true);
  txtChat.setWrapStyleWord(true);
  txtChat.setBackground(new Color(248, 246, 255));
  txtChat.setBorder(new EmptyBorder(5, 5, 5, 5));

  panel.add(new JScrollPane(txtChat), BorderLayout.CENTER);

  JPanel input = new JPanel(new BorderLayout(5, 5));
  input.setOpaque(false);

  txtChatInput = new JTextField();
  btnSendChat = new JButton("Send");
  styleSecondary(btnSendChat);
  btnSendChat.addActionListener(e -> sendChat());

  input.add(txtChatInput, BorderLayout.CENTER);
  input.add(btnSendChat, BorderLayout.EAST);

  panel.add(input, BorderLayout.SOUTH);
  return panel;
  ```

  }

  private JPanel buildEventsPanel() {
  RoundedPanel panel = new RoundedPanel();
  panel.setLayout(new BorderLayout());
  panel.setBorder(new TitledBorder(new LineBorder(new Color(210, 210, 230)), "Game Events"));
  ((TitledBorder) panel.getBorder()).setTitleFont(TextFX.getSubtitleFont());

  ```
  txtEvents = new JTextArea();
  txtEvents.setEditable(false);
  txtEvents.setLineWrap(true);
  txtEvents.setWrapStyleWord(true);
  txtEvents.setBackground(new Color(248, 246, 255));
  txtEvents.setBorder(new EmptyBorder(5, 5, 5, 5));

  panel.add(new JScrollPane(txtEvents), BorderLayout.CENTER);
  panel.setPreferredSize(new Dimension(260, 220));
  return panel;
  ```

  }

  // ===========================================================
  // GAME PANEL
  // ===========================================================
  private JPanel buildGamePanel() {
  RoundedPanel panel = new RoundedPanel();
  panel.setLayout(new BorderLayout(5, 5));
  panel.setBorder(new TitledBorder(new LineBorder(new Color(210, 210, 230)), "Game"));
  ((TitledBorder) panel.getBorder()).setTitleFont(TextFX.getSubtitleFont());

  ```
  JPanel top = new JPanel(new BorderLayout());
  top.setOpaque(false);

  lblCategory = new JLabel("Category: -");
  lblTimer = new JLabel("Timer: -", SwingConstants.RIGHT);
  TextFX.setSubtitleFont(lblCategory);
  TextFX.setSubtitleFont(lblTimer);

  top.add(lblCategory, BorderLayout.WEST);
  top.add(lblTimer, BorderLayout.EAST);
  panel.add(top, BorderLayout.NORTH);

  lblQuestion = new JLabel("Question appears here.", SwingConstants.CENTER);
  lblQuestion.setBorder(new EmptyBorder(40, 20, 40, 20));
  TextFX.setSubtitleFont(lblQuestion);

  panel.add(lblQuestion, BorderLayout.CENTER);

  JPanel answers = new JPanel(new GridLayout(2, 2, 10, 10));
  answers.setOpaque(false);
  answers.setBorder(new EmptyBorder(10, 40, 20, 40));

  for (int i = 0; i < 4; i++) {
      int idx = i;
      JButton btn = new JButton("Answer " + (i + 1));
      styleAnswer(btn);
      btn.addActionListener(e -> answerClicked(idx));
      answerButtons[i] = btn;
      answers.add(btn);
  }

  panel.add(answers, BorderLayout.SOUTH);
  return panel;
  ```

  }

  // ===========================================================
  // NETWORKING
  // ===========================================================
  private void connectClicked(ActionEvent e) {
  if (connected) return;

  ```
  try {
      String host = txtHost.getText().trim();
      int port = Integer.parseInt(txtPort.getText().trim());

      socket = new Socket(host, port);
      out = new ObjectOutputStream(socket.getOutputStream());
      in = new ObjectInputStream(socket.getInputStream());
      connected = true;

      appendEvent("Connected to server.");
      lblConnectHint.setText("Connected as " + txtUser.getText() +
              ". Step 2: Click READY.");

      ConnectionPayload cp = new ConnectionPayload();
      cp.setPayloadType(PayloadType.CLIENT_CONNECT);
      cp.setClientName(txtUser.getText().trim());
      send(cp);

      startReaderThread();
  } catch (Exception ex) {
      appendEvent("Connect failed: " + ex.getMessage());
  }
  ```

  }

  private void startReaderThread() {
  Thread t = new Thread(() -> {
  try {
  while (connected) {
  Object obj = in.readObject();
  if (obj instanceof Payload p) handlePayload(p);
  }
  } catch (Exception ex) {
  appendEvent("Disconnected.");
  connected = false;
  }
  });
  t.start();
  }

  private void handlePayload(Payload p) {
  switch (p.getPayloadType()) {

  ```
      case CLIENT_ID -> {
          clientId = p.getClientId();
          appendEvent("Your ID: " + clientId);
      }

      case MESSAGE -> handleMessagePayload(p);

      case TIMER -> lblTimer.setText("Timer: " + p.getMessage());

      case QUESTION -> handleQA((QAPayload) p);

      case USER_LIST -> handleUserList((UserListPayload) p);

      case POINTS_UPDATE -> appendEvent(p.getMessage());

      default -> {}
  }
  ```

  }

  private void handleMessagePayload(Payload p) {
  if (p.getMessage() == null) return;

  ```
  String msg = p.getMessage();

  if (msg.startsWith("[CHAT] ")) {
      appendChat(msg.substring(7));
  } else {
      appendEvent(msg);
      if (msg.contains("GAME OVER")) {
          lblQuestion.setText("Game over. Click READY to play again.");
          for (JButton btn : answerButtons) {
              btn.setEnabled(false);
          }
      }
  }
  ```

  }

  private void handleQA(QAPayload q) {
  lockedThisRound = false;
  lblCategory.setText("Category: " + q.getCategory());
  lblQuestion.setText(q.getQuestionText());

  ```
  ArrayList<String> ans = q.getAnswers();
  for (int i = 0; i < 4; i++) {
      if (ans != null && i < ans.size()) {
          answerButtons[i].setText(ans.get(i));
          answerButtons[i].setEnabled(true);
          answerButtons[i].setBackground(new Color(240, 236, 255));
      } else {
          answerButtons[i].setText("-");
          answerButtons[i].setEnabled(false);
      }
  }
  ```

  }

  private void handleUserList(UserListPayload up) {
  userModel.clear();
  users.clear();

  ```
  for (int i = 0; i < up.getClientIds().size(); i++) {
      long id = up.getClientIds().get(i);
      String name = up.getDisplayNames().get(i);
      int pts = up.getPoints().get(i);
      boolean locked = up.getLockedIn().get(i);
      boolean away = up.getAway().get(i);
      boolean spec = up.getSpectator().get(i);

      User u = new User(id, name, pts, locked, away, spec);
      users.put(id, u);
      userModel.addElement(u);
  }
  ```

  }

  // ===========================================================
  // ACTIONS
  // ===========================================================
  private void answerClicked(int idx) {
  if (!connected || lockedThisRound || isSpectator || isAway) return;

  ```
  sendCommand("/answer " + idx);
  lockedThisRound = true;

  for (JButton btn : answerButtons) btn.setEnabled(false);
  answerButtons[idx].setBackground(new Color(170, 230, 190));
  ```

  }

  private void sendChat() {
  if (!connected) return;
  if (isSpectator) {
  appendEvent("Spectators cannot chat.");
  return;
  }

  ```
  String msg = txtChatInput.getText().trim();
  if (msg.isEmpty()) return;

  Payload p = new Payload();
  p.setPayloadType(PayloadType.MESSAGE);
  p.setClientId(clientId);
  p.setMessage(msg);
  send(p);

  txtChatInput.setText("");
  ```

  }

  private void sendCommand(String cmd) {
  if (!connected) return;

  ```
  Payload p = new Payload();
  p.setPayloadType(PayloadType.MESSAGE); // server interprets slash commands inside MESSAGE
  p.setClientId(clientId);
  p.setMessage(cmd);
  send(p);
  ```

  }

  private void sendCategories() {
  if (!connected) return;

  ```
  String cats = "";
  if (chkGeo.isSelected()) cats += "geography,";
  if (chkSci.isSelected()) cats += "science,";
  if (chkMath.isSelected()) cats += "math,";
  if (chkHist.isSelected()) cats += "history,";

  if (!cats.isEmpty()) {
      cats = cats.substring(0, cats.length() - 1);
      sendCommand("/categories " + cats);
  }
  ```

  }

  private void toggleAway() {
  isAway = chkAway.isSelected();
  if (isAway) sendCommand("/away");
  else sendCommand("/back");
  }

  private void toggleSpectator() {
  boolean newState = chkSpectator.isSelected();
  if (newState && !isSpectator) {
  isSpectator = true;
  sendCommand("/spectate");
  }
  }

  private void showAddQDialog() {
  if (!connected) {
  appendEvent("Not connected.");
  return;
  }

  ```
  String cat = JOptionPane.showInputDialog(frame,
          "Category (geography, science, math, history):");
  if (cat == null || cat.trim().isEmpty()) return;

  String q = JOptionPane.showInputDialog(frame, "Question:");
  if (q == null || q.trim().isEmpty()) return;

  String a1 = JOptionPane.showInputDialog(frame, "Answer A:");
  String a2 = JOptionPane.showInputDialog(frame, "Answer B:");
  String a3 = JOptionPane.showInputDialog(frame, "Answer C:");
  String a4 = JOptionPane.showInputDialog(frame, "Answer D:");
  String correct = JOptionPane.showInputDialog(frame,
          "Correct index (0=A, 1=B, 2=C, 3=D):");

  if (a1 == null || a2 == null || a3 == null || a4 == null || correct == null) return;

  String line = cat + "|" + q + "|" + a1 + "|" + a2 + "|" + a3 + "|" + a4 + "|" + correct;
  sendCommand("/addq " + line);
  ```

  }

  private void send(Payload p) {
  try {
  out.writeObject(p);
  out.flush();
  } catch (Exception ex) {
  appendEvent("Send failed: " + ex.getMessage());
  }
  }

  // ===========================================================
  // HELPERS
  // ===========================================================
  private JLabel label(String text) {
  JLabel lbl = new JLabel(text);
  TextFX.setSubtitleFont(lbl);
  return lbl;
  }

  private void stylePrimary(JButton btn) {
  btn.setBackground(new Color(130, 110, 250));
  btn.setForeground(Color.WHITE);
  btn.setBorder(new LineBorder(new Color(110, 90, 230), 1, true));
  TextFX.setSubtitleFont(btn);
  }

  private void styleSecondary(JButton btn) {
  btn.setBackground(new Color(240, 236, 255));
  btn.setForeground(new Color(70, 70, 110));
  btn.setBorder(new LineBorder(new Color(200, 190, 240), 1, true));
  TextFX.setSubtitleFont(btn);
  }

  private void styleAnswer(JButton btn) {
  btn.setBackground(new Color(240, 236, 255));
  btn.setForeground(new Color(70, 70, 110));
  btn.setBorder(new LineBorder(new Color(200, 190, 240), 1, true));
  TextFX.setSubtitleFont(btn);
  }

  private void appendEvent(String msg) {
  txtEvents.append(msg + "\n");
  txtEvents.setCaretPosition(txtEvents.getDocument().getLength());
  }

  private void appendChat(String msg) {
  txtChat.append(msg + "\n");
  txtChat.setCaretPosition(txtChat.getDocument().getLength());
  }

  // ===========================================================
  // ROUNDED PANEL CLASS
  // ===========================================================
  static class RoundedPanel extends JPanel {
  public RoundedPanel() {
  setOpaque(false);
  }

  ```
  @Override
  protected void paintComponent(Graphics g) {
      Graphics2D g2 = (Graphics2D) g.create();
      g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
              RenderingHints.VALUE_ANTIALIAS_ON);

      int arc = 20;
      Color fill = new Color(252, 250, 255);
      Color border = new Color(220, 215, 240);

      g2.setColor(new Color(220, 215, 240, 120));
      g2.fillRoundRect(4, 6, getWidth() - 4, getHeight() - 4, arc, arc);

      g2.setColor(fill);
      g2.fillRoundRect(0, 0, getWidth() - 6, getHeight() - 6, arc, arc);

      g2.setColor(border);
      g2.drawRoundRect(0, 0, getWidth() - 6, getHeight() - 6, arc, arc);

      g2.dispose();
      super.paintComponent(g);
  }
  ```

  }
  }
