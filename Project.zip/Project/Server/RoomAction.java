// UCID: nhd5
// Date: November 3, 2025
// Description: TriviaGuessGame RoomAction – defines room actions
// Reference: https://www.w3schools.com/java/

package Server;

public enum RoomAction {
    CREATE, JOIN, LEAVE
}
